import pygame
import sys
import random  # Required to generate random positions
import asyncio
# Initialize Pygame

async def main():
    pygame.init()


    # Window Setup
    WIDTH, HEIGHT = 800, 600
    TEXT_COLOR = (255,255,255)
    SCORE_FONT = pygame.font.Font(None, 30) 
    score = 0
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Detective Game")
    clock = pygame.time.Clock()

    player_sprite_surface = pygame.image.load("player.png").convert_alpha()
    collect_sprite_surface = pygame.image.load("cupcake.png").convert_alpha()
    player_sprite_surface = pygame.transform.smoothscale(player_sprite_surface, (64, 64))
    collect_sprite_surface = pygame.transform.smoothscale(collect_sprite_surface, (32, 32))

    # Convert Raw Base64 string back into a Pygame Surface
    player_sprite_surface = pygame.image.load("player.png").convert_alpha()
    collect_sprite_surface = pygame.image.load("cupcake.png").convert_alpha()
    player_sprite_surface = pygame.transform.smoothscale(player_sprite_surface, (64,64))
    collect_sprite_surface = pygame.transform.smoothscale(collect_sprite_surface, (32,32))

    background_sound = pygame.mixer.Sound("music.ogg")
    background_sound.set_volume(0.5)  # 0.0 to 1.0

    # Colors
    BACKGROUND = (30, 30, 40)
    RED = (255, 0, 0)
    WHITE = (255,255,255)


    # Player Hitbox (Invisible)
    player_rect = pygame.Rect(380, 100, 60, 60)
    player_vel_x = 0
    player_vel_y = 0
    player_speed = 10


    # Physics Constants
    GRAVITY = 0.8
    JUMP_STRENGTH = -15
    is_grounded = False  


    # 3 Platforms
    platforms = [
        pygame.Rect(0, 525, 800, 50), pygame.Rect(100, 400, 250, 20), pygame.Rect(500, 300, 250, 20),
        pygame.Rect(0, 100, 100, 50), pygame.Rect(300, 200, 50, 50), pygame.Rect(100, 150, 20, 200),
        pygame.Rect(700, 75, 20, 175)
    ]

    def spawn_cupcake():
        return pygame.Rect(random.randint(100, 600), random.randint(50, 500), 25, 25)

    # --- ADDING 10 CUPCAKES ---
    cupcakes = [spawn_cupcake() for _ in range(10)]

    pygame.mixer.music.load("music.ogg")
    pygame.mixer.music.set_volume(0.3)
    pygame.mixer.music.play(-1)

    # Main Game Loop
    running = True
    while running:
        # 1. Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
        # 2. Keyboard Input (Arrow Keys)
        keys = pygame.key.get_pressed()
        player_vel_x = 0

        if keys[pygame.K_LEFT]:
            player_vel_x = -player_speed
        if keys[pygame.K_RIGHT]:
            player_vel_x = player_speed
        if keys[pygame.K_UP] and is_grounded:
            player_vel_y = JUMP_STRENGTH
            is_grounded = False


        # Apply Gravity
        player_vel_y += GRAVITY


        # Move Horizontally & Handle Screen Boundaries
        player_rect.x += player_vel_x
        if player_rect.left < 0: player_rect.left = 0
        if player_rect.right > WIDTH: player_rect.right = WIDTH


        # Move Vertically & Handle Safe Platform Collisions
        player_rect.y += player_vel_y
        is_grounded = False  

        for platform in platforms:
            if player_rect.colliderect(platform):
                if player_vel_y > 0:  # Falling down
                    player_rect.bottom = platform.top
                    player_vel_y = 0
                    is_grounded = True
                elif player_vel_y < 0:  # Jumping up
                    player_rect.top = platform.bottom
                    player_vel_y = 0


        # Fall-back safety screen floor boundary check
        if player_rect.bottom > 550:
            player_rect.bottom = 550
            player_vel_y = 0
            is_grounded = True


        # --- CUPCAKE COLLECTION LOGIC ---
        # Slicing the list [:] creates a shallow copy, allowing safe item removal
        for cupcake in cupcakes[:]:
            if player_rect.colliderect(cupcake):
                cupcakes.remove(cupcake)
                score+=1
                cupcakes.append(spawn_cupcake())

        # 3. Rendering
        screen.fill(BACKGROUND)


        # Draw 3 Blue Platforms
        for platform in platforms:
            pygame.draw.rect(screen, WHITE, platform)


        # Draw Cupcakes (Yellow Circles drawn using the center of the bounding Rect)
        for cupcake in cupcakes:
            screen.blit(collect_sprite_surface, collect_sprite_surface.get_rect(center=cupcake.center))


        # Draw Player (Red Square)
        screen.blit(player_sprite_surface, player_sprite_surface.get_rect(midbottom=player_rect.midbottom))


        # Refresh Screen
        score_surface = SCORE_FONT.render(str(score), True, (TEXT_COLOR))
        screen.blit(score_surface, (20,20))
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())